<?php
$Servidor = "127.0.0.1";
$Usuario = "root";
$Senha = "";
$Basededao = "covid";
$conexao=mysqli_connect("$Servidor","$Usuario","$Senha","$Basededao");
//header("refresh: 2");